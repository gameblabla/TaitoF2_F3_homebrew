set neodev=c:\neodev
set path=c:\neodev\bin;%path%
